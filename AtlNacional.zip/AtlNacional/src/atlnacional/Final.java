package atlnacional;


public class Final extends informacion {
    
    private String equipofinal;
    private int golesfinal;
    
    public Final(String equipofinal, int golesfinal, String titulo, int numerotitulos, int fechavictoria){
        super(titulo, numerotitulos, fechavictoria);
        this.equipofinal = equipofinal;
        this.golesfinal = golesfinal;
    }

    public String getEquipofinal() {
        return equipofinal;
    }

    public void setEquipofinal(String equipofinal) {
        this.equipofinal = equipofinal;
    }

    public int getGolesfinal() {
        return golesfinal;
    }

    public void setGolesfinal(int golesfinal) {
        this.golesfinal = golesfinal;
    }
    
    @Override
    public void mostrarInformacion(){
        super.mostrarInformacion();
        System.out.println("Equipo final: " + equipofinal);
        System.out.println("Goles en la final: " + golesfinal);
    }
    
}
