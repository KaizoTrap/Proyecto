
package atlnacional;


public class Partidos implements Clasicos{
    
    @Override
    public void ClasicoPaisa(){
        System.out.println("Jugar contra deportivo medellin");
    }

    @Override
    public void ClasicoColombiano() {
        System.out.println("Jugar contra Millonarios");
    }
    
    public void ClasicoPaisa(String fecha, String lugar) {
        System.out.println("Jugar contra Deportivo Medellín");
        System.out.println("Fecha del partido: " + fecha);
        System.out.println("Lugar: " + lugar);
    }
    
    public void ClasicoColombiano(String fecha, String lugar) {
        System.out.println("Jugar contra Millonarios");
        System.out.println("Fecha del partido: " + fecha);
        System.out.println("Lugar: " + lugar);
    }
}
