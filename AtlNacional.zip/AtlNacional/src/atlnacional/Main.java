package atlnacional;

public class Main {
    public static void main(String[] args) {
        try {
            // Creación de objetos de la clase 'informacion'
            informacion info = new informacion("Liga Colombiana", 17, 2023);
            info.mostrarInformacion();  // Mostrar información sobre los títulos

            // Llamada a los métodos de la clase 'informacion' (heredados de 'titulos')
            info.menostitulos();  // Mostrar cantidad de títulos

            // Llamada al método verificarTitulos con un límite específico
            info.verificarTitulos(info.getNumeroTitulos(), 20);

            // Creación de un objeto de la clase 'Final' (hereda de 'informacion')
            Final finalPartido = new Final("Independiente Medellín", 2, "Copa América", 8, 2016);
            finalPartido.mostrarInformacion();  // Mostrar información sobre la final

            // Instanciar la clase 'Partidos' que implementa la interfaz 'Clasicos'
            Partidos partidos = new Partidos();

            // Llamar a los métodos implementados desde la interfaz 'Clasicos'
            partidos.ClasicoPaisa();  // Llamada sin parámetros
            partidos.ClasicoColombiano();  // Llamada sin parámetros

            // Llamar a los métodos sobrecargados con parámetros adicionales
            partidos.ClasicoPaisa("12 de diciembre de 2024", "Estadio Atanasio Girardot");
            partidos.ClasicoColombiano("15 de enero de 2025", "Estadio El Campín");

        } catch (Exception e) {
            // Manejo de excepciones
            System.out.println("Ha ocurrido un error: " + e.getMessage());
            e.printStackTrace();  // Muestra el detalle del error para depuración
        }
    }
}

