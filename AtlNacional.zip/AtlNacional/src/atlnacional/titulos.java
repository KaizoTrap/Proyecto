package atlnacional;

public abstract class titulos {
    
    // Método abstracto, que debe ser implementado por las subclases
    public abstract void menostitulos();
    
    // Método concreto para verificar si el número de títulos es menor que un valor específico
    public void verificarTitulos(int numeroTitulos, int limite) {
        if (numeroTitulos < limite) {
            System.out.println("El número de títulos es menor que " + limite);
        } else {
            System.out.println("El número de títulos es mayor o igual que " + limite);
        }
    }
}

