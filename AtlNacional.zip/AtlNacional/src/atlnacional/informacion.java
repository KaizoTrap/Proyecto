package atlnacional;

public class informacion extends titulos {
    
    private String titulo;
    private int numeroTitulos;
    private int fechavictoria;
    
    // Constructor
    public informacion(String titulo, int numeroTitulos, int fechavictoria) {
        this.titulo = titulo;
        this.numeroTitulos = numeroTitulos;
        this.fechavictoria = fechavictoria;
    }

    @Override
    public void menostitulos() {
        System.out.println("El equipo " + titulo + " tiene " + numeroTitulos + " títulos.");
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getNumeroTitulos() {
        return numeroTitulos;
    }

    public void setNumeroTitulos(int numeroTitulos) {
        this.numeroTitulos = numeroTitulos;
    }

    public int getFechavictoria() {
        return fechavictoria;
    }

    public void setFechavictoria(int fechavictoria) {
        this.fechavictoria = fechavictoria;
    }

    public void mostrarInformacion(){
        System.out.println("Título: " + titulo);
        System.out.println("Número de títulos: " + numeroTitulos);
        System.out.println("Año de victoria:" + fechavictoria);
    }
    
}

