package atlnacional;


public interface Clasicos {
    
    public abstract void ClasicoPaisa();
    public abstract void ClasicoColombiano();
}
